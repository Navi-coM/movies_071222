import React from 'react';
import { MovieList } from '../components/MovieList';


class Main extends React.Component {
    state = {
        movieList: []
    }

    componentDidMount() {
        fetch('http://www.omdbapi.com/?apikey=545d2dce&s=Titanic')
            .then(response => response.json())
            .then(data => this.setState({movieList: data.Search}))
    }
    render() {
        const {movieList} = this.state;
        return (
            <main className="content container main">
                {
                    movieList.length ? (<MovieList movieList={this.state.movieList}/>) : <h3>Loading...</h3>
                }
            </main>
        )
    }
}

export {Main};

